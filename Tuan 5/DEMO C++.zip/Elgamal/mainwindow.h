#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFileDialog>
#include <QMessageBox>
#include <QFile>
#include <QTextStream>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    // Khai báo 3 hàm toán học lõi xử lý ElGamal
    long long powerMod(long long base, long long exp, long long mod);
    long long modInverse(long long a, long long m);
    long long hashFileToNumber(const std::string& filePath, long long p);
    bool isPrime(long long n);
    unsigned long long mulMod(unsigned long long a, unsigned long long b, unsigned long long mod);
    unsigned long long powerModLarge(unsigned long long base, unsigned long long exp, unsigned long long mod);
    bool MillerRabin(unsigned long long n, int iteration = 5);
    QString stringMod(QString num, QString mod);
    QString stringMul(QString num1, QString num2);
    QString stringPowerMod(QString base, QString exp, QString mod);
    QString stringSub(QString num1, QString num2); // Phép trừ số lớn dạng chuỗi
    QString stringGCD(QString num1, QString num2);

private slots:
    // KHAI BÁO CÁC NÚT BẤM CỦA SƠN Ở ĐÂY:
    void on_btntao_clicked();
    void on_btnTaoKhoaNgauNhien_clicked();
    void on_btnreset_clicked();
    void on_btnchon1_clicked();
    void on_btnKyTaiLieu_clicked();
    void on_btnLuuChuKy_clicked();
    void on_btnchon2_clicked();
    void on_btnchon_clicked();
    void on_btnXacMinh_clicked();
private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H