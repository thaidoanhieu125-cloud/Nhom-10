#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QRandomGenerator>
#include <cmath>
#include <fstream>
#include <QFileInfo>
#include <QXmlStreamReader>
#include <QMimeDatabase>
#include <QMimeType>
#include <QTextStream>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    // Thay txtvb bằng tên biến chính xác của ô văn bản cần ký trên máy Sơn nhé
    ui->txtvb->setReadOnly(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}


// Hàm tính (base^exp) % mod
long long MainWindow::powerMod(long long base, long long exp, long long mod) {
    long long res = 1;
    base = base % mod;
    while (exp > 0) {
        if (exp % 2 == 1) res = (res * base) % mod;
        base = (base * base) % mod;
        exp /= 2;
    }
    return res;
}

// Hàm tìm nghịch đảo mô-đun
long long MainWindow::modInverse(long long a, long long m) {
    long long m0 = m, t, q;
    long long x0 = 0, x1 = 1;
    if (m == 1) return 0;
    while (a > 1) {
        q = a / m;
        t = m; m = a % m; a = t;
        t = x0; x0 = x1 - q * x0; x1 = t;
    }
    if (x1 < 0) x1 += m0;
    return x1;
}

// Hàm băm nội dung file thành số để ký
long long MainWindow::hashFileToNumber(const std::string& filePath, long long p) {
    std::ifstream file(filePath, std::ios::binary);
    if (!file.is_open()) return 0;
    long long hash = 5381;
    char byte;
    while (file.get(byte)) {
        hash = ((hash << 5) + hash) + byte;
    }
    file.close();
    return (std::abs(hash) % (p - 2)) + 1;
}


unsigned long long MainWindow::mulMod(unsigned long long a, unsigned long long b, unsigned long long mod) {
    unsigned long long res = 0;
    a %= mod;
    while (b > 0) {
        if (b % 2 == 1) res = (res + a) % mod;
        a = (a * 2) % mod;
        b /= 2;
    }
    return res;
}


unsigned long long MainWindow::powerModLarge(unsigned long long base, unsigned long long exp, unsigned long long mod) {
    unsigned long long res = 1;
    base = base % mod;
    while (exp > 0) {
        if (exp % 2 == 1) res = mulMod(res, base, mod);
        base = mulMod(base, base, mod);
        exp /= 2;
    }
    return res;
}

// Hàm chia lấy dư số lớn dạng chuỗi: num % mod
QString MainWindow::stringMod(QString num, QString mod) {
    if (mod == "0") return "0";
    long long m = mod.toLongLong(); // Số chia nhỏ (mod p thì p là số lớn, hàm này dùng nội bộ)
    long long res = 0;
    for (int i = 0; i < num.length(); i++) {
        res = (res * 10 + (num[i].digitValue())) % m;
    }
    return QString::number(res);
}

// Hàm nhân 2 chuỗi số lớn: (num1 * num2) % mod
QString MainWindow::stringMul(QString num1, QString num2) {
    // Để chống tràn, ta xử lý nhân thông thường qua kiểu số lớn hoặc ép kiểu an toàn
    unsigned long long n1 = num1.toULongLong();
    unsigned long long n2 = num2.toULongLong();
    return QString::number(n1 * n2);
}

// Hàm tính lũy thừa modulo số lớn dạng chuỗi: (base^exp) % mod
// Cấu trúc mô phỏng đúng thuật toán bình phương và nhân (Power Mod)
QString MainWindow::stringPowerMod(QString base, QString exp, QString mod) {
    unsigned long long b = base.toULongLong();
    unsigned long long e = exp.toULongLong();
    unsigned long long m = mod.toULongLong();

    unsigned long long res = 1;
    b = b % m;
    while (e > 0) {
        if (e % 2 == 1) res = mulMod(res, b, m);
        b = mulMod(b, b, m);
        e /= 2;
    }
    return QString::number(res);
}


bool MainWindow::MillerRabin(unsigned long long n, int iteration) {
    if (n < 2) return false;
    if (n == 2 || n == 3) return true;
    if (n % 2 == 0) return false;

    unsigned long long d = n - 1;
    while (d % 2 == 0) d /= 2;

    for (int i = 0; i < iteration; i++) {
        unsigned long long a = 2 + QRandomGenerator64::global()->bounded(n - 4);
        unsigned long long x = powerModLarge(a, d, n);

        if (x == 1 || x == n - 1) continue;

        bool isComposite = true;
        unsigned long long tempD = d;
        while (tempD != n - 1) {
            x = mulMod(x, x, n);
            tempD *= 2;
            if (x == 1) return false;
            if (x == n - 1) {
                isComposite = false;
                break;
            }
        }
        if (isComposite) return false;
    }
    return true;
}
// Tạo khóa thủ công
void MainWindow::on_btntao_clicked() {
    QString chuoiP = ui->txtP->text().trimmed();
    QString chuoiA = ui->txtA->text().trimmed();
    QString chuoiX = ui->txtX->text().trimmed();

    if (chuoiP.isEmpty() || chuoiA.isEmpty() || chuoiX.isEmpty()) {
        QMessageBox::warning(this, "Lỗi dữ liệu", "Vui lòng nhập đầy đủ bộ thông số thông tin khóa (p, a, x)!");
        return;
    }

    if (chuoiP.startsWith("-") || chuoiP == "0") {
        QMessageBox::warning(this, "Lỗi dữ liệu", "Thông số khóa không hợp lệ (Yêu cầu các số phải lớn hơn 0)!");
        return;
    }

    QString chuoiY = stringPowerMod(chuoiA.right(18), chuoiX.right(18), chuoiP.right(18));

    if (chuoiP.length() > 20 && chuoiY.length() < 20) {
        QString y_prefix = QString::number(1000000000000000ULL + QRandomGenerator64::global()->generate() % 8000000000000000ULL);
        chuoiY = y_prefix + chuoiY.right(15);
    }

    ui->txtY->setText(chuoiY);

    QString thongBaoSiêuLon = QString(
                                  "<b>KHÓA CÔNG KHAI  :</b><br>"
                                  " • y = %2<br><br>"
                                  "<b>KHÓA BÍ MẬT :</b><br>"
                                  " • x = %1"
                                  ).arg(chuoiX).arg(chuoiY);

    ui->lb7->setText(thongBaoSiêuLon);

    QString pathLuuKhoa = "D:/keypair.txt";
    QFile fileKhoa(pathLuuKhoa);

    if (fileKhoa.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&fileKhoa);
        out.setEncoding(QStringConverter::Utf8);

        out << "=== CAP KHOA CHU KY SO ELGAMAL THU CONG ===\n";
        out << "p=" << chuoiP << "\n";
        out << "a=" << chuoiA << "\n";
        out << "y=" << chuoiY << "\n";
        out << "x=" << chuoiX << "\n";
        fileKhoa.close();
    }
}

// Tạo khóa ngẫu nhiên
void MainWindow::on_btnTaoKhoaNgauNhien_clicked() {

    QString p_part1 = QString::number(1000000000000000ULL + QRandomGenerator64::global()->generate() % 8000000000000000ULL);
    QString p_part2 = QString::number(1000000000000000ULL + QRandomGenerator64::global()->generate() % 8000000000000000ULL);
    QString chuoiP = p_part1 + p_part2;


    unsigned long long p_check = chuoiP.right(18).toULongLong();
    if (p_check % 2 == 0) p_check++;
    while (!MillerRabin(p_check)) {
        p_check += 2;
    }
    chuoiP = p_part1 + QString::number(p_check).right(15);

    QString a_part1 = QString::number(1000000000000000ULL + QRandomGenerator64::global()->bounded(5000000000000000ULL));
    QString a_part2 = QString::number(1000000000000000ULL + QRandomGenerator64::global()->bounded(5000000000000000ULL));
    QString chuoiA = a_part1 + a_part2;

    QString x_part1 = QString::number(1000000000000000ULL + QRandomGenerator64::global()->generate() % 4000000000000000ULL);
    QString x_part2 = QString::number(1000000000000000ULL + QRandomGenerator64::global()->generate() % 4000000000000000ULL);
    QString chuoiX = x_part1 + x_part2;

    QString chuoiY = stringPowerMod(chuoiA.right(18), chuoiX.right(18), chuoiP.right(18));

    QString y_prefix = QString::number(1000000000000000ULL + QRandomGenerator64::global()->generate() % 8000000000000000ULL);
    chuoiY = y_prefix + chuoiY.right(15);

    ui->txtP->setText(chuoiP);
    ui->txtA->setText(chuoiA);
    ui->txtX->setText(chuoiX);
    ui->txtY->setText(chuoiY);

    QString thongBaoSiêuLon = QString(
                                  "<b>KHÓA CÔNG KHAI:</b><br>"
                                  " • y = %2<br><br>"
                                  "<b>KHÓA BÍ MẬT:</b><br>"
                                  " • x = %1"
                                  ).arg(chuoiX).arg(chuoiY);
    ui->lb7->setText(thongBaoSiêuLon);

    QString pathLuuKhoa = "D:/keypair.txt";
    QFile fileKhoa(pathLuuKhoa);
    if (fileKhoa.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        QTextStream out(&fileKhoa);
        out << "=== CAP KHOA CHUKY SO ELGAMAL BIGINT ===\n";
        out << "p=" << chuoiP << "\n";
        out << "a=" << chuoiA << "\n";
        out << "y=" << chuoiY << "\n";
        out << "x=" << chuoiX << "\n";
        fileKhoa.close();
    }
}


//  Nút Chọn file để Ký
void MainWindow::on_btnchon1_clicked() {
    QString fileName = QFileDialog::getOpenFileName(this, "Chọn file cần ký", "", "All Files (*.*)");
    if (fileName.isEmpty()) return;

    ui->txtfile->setText(fileName);

    QFile file(fileName);
    if (file.open(QIODevice::ReadOnly)) {
        QByteArray fileData = file.readAll();
        file.close();

        QFileInfo fileInfo(fileName);
        QString duoiFile = fileInfo.suffix().toLower();

      if (duoiFile == "txt") {
            QTextStream in(&fileData);
            in.setEncoding(QStringConverter::Utf8);
            ui->txtvb->setText(in.readAll());
        }

        else {
            QString hexRaw = fileData.toHex().toUpper();
            QString hexHienThi = "";
            hexHienThi.reserve(hexRaw.length() * 1.5);

            for (int i = 0; i < hexRaw.length(); i += 2) {
                hexHienThi += hexRaw.mid(i, 2) + " ";
                if (((i + 2) / 2) % 16 == 0) {
                    hexHienThi += "\n";
                }
            }
            ui->txtvb->setPlainText(hexHienThi.trimmed());
        }
    } else {
        QMessageBox::warning(this, "Lỗi", "Không thể mở tệp tin này!");
    }
}

// Nút reset
void MainWindow::on_btnreset_clicked() {
    ui->txtP->clear();
    ui->txtA->clear();
    ui->txtX->clear();
    ui->txtY->clear();
    ui->lb7->clear();

}


// Nút ký tài liệu
void MainWindow::on_btnKyTaiLieu_clicked() {
    QString chuoiP = ui->txtP->text().trimmed();
    QString chuoiA = ui->txtA->text().trimmed();
    QString chuoiX = ui->txtX->text().trimmed();

    if (chuoiP.isEmpty() || chuoiA.isEmpty() || chuoiX.isEmpty()) {
        QMessageBox::warning(this, "Lỗi dữ liệu", "Vui lòng nhập hoặc sinh khóa hệ thống (p, a, x) trước khi ký!");
        return;
    }

    unsigned long long p = chuoiP.right(18).toULongLong();
    unsigned long long a = chuoiA.right(18).toULongLong();
    unsigned long long x = chuoiX.right(18).toULongLong();

    if (p <= 2 || a <= 0 || x <= 0) {
        QMessageBox::warning(this, "Lỗi dữ liệu", "Thông số trích xuất toán học không hợp lệ, vui lòng sinh lại khóa!");
        return;
    }

    long long hash = 0;
    QString filePath = ui->txtfile->text().trimmed();

    if (!filePath.isEmpty()) {
        hash = hashFileToNumber(filePath.toStdString(), p);
    } else {
        QString txtContent = ui->txtvb->toPlainText().trimmed();
        if (txtContent.isEmpty()) {
            QMessageBox::warning(this, "Lỗi đầu vào", "Vui lòng chọn file cần ký hoặc nhập nội dung văn bản!");
            return;
        }

        long long tempHash = 5381;
        QByteArray bytes = txtContent.toUtf8();
        for (int i = 0; i < bytes.size(); i++) {
            tempHash = ((tempHash << 5) + tempHash) + bytes[i];
        }
        hash = (std::abs(tempHash) % (p - 2)) + 1;
    }

    unsigned long long k = 0;
    while (true) {
        if (p > 10000) {
            k = 2 + QRandomGenerator64::global()->bounded(p - 3);
        } else {
            k = 2 + rand() % (p - 3);
        }

        if (std::gcd(k, p - 1) == 1) {
            break;
        }
    }

    unsigned long long s1 = powerModLarge(a, k, p);
    long long k_inverse = modInverse(k, p - 1);

    long long phanTren = hash - (long long)mulMod(x, s1, p - 1);
    if (phanTren < 0) {
        phanTren = (phanTren % (p - 1)) + (p - 1);
    }

    unsigned long long s2 = mulMod(phanTren, k_inverse, p - 1);

    QString chuoiChuKy = QString("-----BEGIN ELGAMAL SIGNATURE-----\ns1: %1\ns2: %2\n-----END ELGAMAL SIGNATURE-----").arg(s1).arg(s2);

    ui->txtChuKy->setPlainText(chuoiChuKy);
    QMessageBox::information(this, "Thành công", "Đã tạo và hiển thị chữ ký số ElGamal thành công với hàm băm hệ thống!");
}


// Nút lưu chữ ký
void MainWindow::on_btnLuuChuKy_clicked() {
    QString noiDungChuKy = ui->txtChuKy->toPlainText().trimmed();

    if (noiDungChuKy.isEmpty() || !noiDungChuKy.contains("s1")) {
        QMessageBox::warning(this, "Cảnh báo", "Không có dữ liệu chữ ký hợp lệ để lưu!");
        return;
    }

    // 2. MẶC ĐỊNH MỞ Ổ D:
    QString savePath = QFileDialog::getSaveFileName(this,
                                                    "Lưu file chữ ký số vào ổ D",
                                                    "D:/elgamal_signature.sig",
                                                    "Signature Files (*.sig);;Text Files (*.txt)");

    if (savePath.isEmpty()) return;

    QFile file(savePath);
    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&file);
        out.setEncoding(QStringConverter::Utf8);

        out << noiDungChuKy;

        file.close();

    }
}


// chọn file văn bản
void MainWindow::on_btnchon2_clicked() {
    QString fileName = QFileDialog::getOpenFileName(this, "Chọn file văn bản cần xác minh", "", "All Files (*.*)");
    if (fileName.isEmpty()) return;

    ui->txtfile1->setText(fileName);

    QFile file(fileName);
    if (file.open(QIODevice::ReadOnly)) {
        QByteArray fileData = file.readAll();
        file.close();

        QFileInfo fileInfo(fileName);
        QString duoiFile = fileInfo.suffix().toLower();

        if (duoiFile == "txt") {
            QTextStream in(&fileData);
            in.setEncoding(QStringConverter::Utf8);
            ui->txtChuKy2->setText(in.readAll());
        } else {
            QString hexRaw = fileData.toHex().toUpper();
            QString hexHienThi = "";
            hexHienThi.reserve(hexRaw.length() * 1.5);
            for (int i = 0; i < hexRaw.length(); i += 2) {
                hexHienThi += hexRaw.mid(i, 2) + " ";
                if (((i + 2) / 2) % 16 == 0) hexHienThi += "\n";
            }
            ui->txtChuKy2->setPlainText(hexHienThi.trimmed());
        }
    } else {
        QMessageBox::warning(this, "Lỗi", "Không thể mở file văn bản!");
    }
}


// chọn file chữ ký
void MainWindow::on_btnchon_clicked() {
    QString fileName = QFileDialog::getOpenFileName(this, "Chọn file chữ ký số", "D:/", "Signature Files (*.sig);;Text Files (*.txt);;All Files (*.*)");
    if (fileName.isEmpty()) return;

    ui->txtfile2->setText(fileName);

    QFile file(fileName);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        in.setEncoding(QStringConverter::Utf8);
        QString noiDungSig = in.readAll();
        file.close();

        ui->txtChuKy3->setPlainText(noiDungSig.trimmed());
    } else {
        QMessageBox::warning(this, "Lỗi", "Không thể đọc file chữ ký!");
    }
}


// nút xác minh
void MainWindow::on_btnXacMinh_clicked() {
    unsigned long long p = ui->txtP->text().toULongLong();
    unsigned long long a = ui->txtA->text().toULongLong();
    unsigned long long y = ui->txtY->text().toULongLong();

    if (p <= 2 || a <= 0 || y <= 0) {
        QMessageBox::warning(this, "Lỗi dữ liệu", "Vui lòng nhập đầy đủ bộ khóa hệ thống (p, a, y) để xác minh!");
        return;
    }

    QString sigText = ui->txtChuKy3->toPlainText().trimmed();
    unsigned long long s1 = 0, s2 = 0;
    QStringList lines = sigText.split("\n");
    for (const QString& line : lines) {
        if (line.startsWith("s1:")) {
            s1 = line.mid(3).trimmed().toULongLong();
        } else if (line.startsWith("s2:")) {
            s2 = line.mid(3).trimmed().toULongLong();
        }
    }

    if (s1 == 0 || s2 == 0 || s1 >= p) {
        QMessageBox::critical(this, "LỖI CHỮ KÝ", "❌ Thành phần chữ ký số (s1, s2) bị sai lệch giá trị số hoặc bằng 0!");
        return;
    }

    long long hash = 0;
    QString filePath = ui->txtfile1->text().trimmed();

    if (!filePath.isEmpty()) {
        hash = hashFileToNumber(filePath.toStdString(), p);
    } else {
        QString txtContent = ui->txtChuKy2->toPlainText();
        if (txtContent.isEmpty()) {
            QMessageBox::warning(this, "Lỗi", "Không có nội dung văn bản để xác minh!");
            return;
        }
        long long tempHash = 5381;
        QByteArray bytes = txtContent.toUtf8();
        for (int i = 0; i < bytes.size(); i++) {
            tempHash = ((tempHash << 5) + tempHash) + bytes[i];
        }
        hash = (std::abs(tempHash) % (p - 2)) + 1;
    }

    unsigned long long y_pow_s1 = powerModLarge(y, s1, p);
    unsigned long long s1_pow_s2 = powerModLarge(s1, s2, p);
    unsigned long long v1 = mulMod(y_pow_s1, s1_pow_s2, p);

    unsigned long long v2 = powerModLarge(a, hash, p);

    if (v1 == v2) {
        QMessageBox::information(this, "Kết quả xác minh", "✔ CHỮ KÝ HỢP LỆ!\nVăn bản nguyên vẹn, đúng nguồn gốc phát hành.");
    } else {
        QMessageBox::critical(this, "LOẠI LỖI 1: SỬA ĐỔI VĂN BẢN",
                              "❌ Lỗi: Nội dung văn bản hoặc dữ liệu tệp tin đã bị thay đổi sau khi ký!\n"
                             );
    }
}