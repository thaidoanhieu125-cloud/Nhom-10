﻿using System;
using System.IO;
using System.Numerics;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Media;
using Microsoft.Win32;
using WpfApp1.Core;
using WpfApp1.Helpers;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private ElGamalPublicKey currentPublicKey;
        private ElGamalPrivateKey currentPrivateKey;

        // Lưu lại mã băm gốc tại thời điểm thực hiện lệnh Ký Số để phục vụ phân tách lỗi ở Bước 3
        private string originalCapturedHash = string.Empty;

        public MainWindow()
        {
            InitializeComponent();
            RegisterEvents();
        }

        private void RegisterEvents()
        {
            // Tab 1
            btnGenerateKey.Click += BtnGenerateKey_Click;
            btnCheckManualKey.Click += BtnCheckManualKey_Click;
            btnSaveKeys.Click += BtnSaveKeys_Click;

            // Tab 2
            btnSelectFileToSign.Click += BtnSelectFileToSign_Click;
            btnPerformSign.Click += BtnPerformSign_Click;
            btnSaveSignature.Click += BtnSaveSignature_Click;

            // Tab 3
            btnSelectFileToVerify.Click += BtnSelectFileToVerify_Click;
            btnLoadPublicKey.Click += BtnLoadPublicKey_Click;
            btnLoadSignatureFile.Click += BtnLoadSignatureFile_Click;
            btnPerformVerify.Click += BtnPerformVerify_Click;
        }

        // ================= TAB 1: LOGIC TẠO KHÓA =================
        private void BtnGenerateKey_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int bitLength = int.Parse(((System.Windows.Controls.ComboBoxItem)cbBitLength.SelectedItem).Content.ToString());
                var keys = ElGamalAlgorithm.GenerateKeys(bitLength);

                currentPublicKey = keys.pubKey;
                currentPrivateKey = keys.privKey;

                txtP.Text = currentPublicKey.P.ToString();
                txtG.Text = currentPublicKey.G.ToString();
                txtY.Text = currentPublicKey.Y.ToString();
                txtX.Text = currentPrivateKey.X.ToString();

                MessageBox.Show("Đã sinh cặp khóa ngẫu nhiên thành công!", "Thông báo", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi hệ thống khi sinh khóa: {ex.Message}");
            }
        }

        private void BtnCheckManualKey_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtP.Text) || string.IsNullOrWhiteSpace(txtG.Text) || string.IsNullOrWhiteSpace(txtX.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ các thông số P, G, X để kiểm tra!", "Cảnh báo", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                BigInteger p = BigInteger.Parse(txtP.Text.Trim());
                BigInteger g = BigInteger.Parse(txtG.Text.Trim());
                BigInteger x = BigInteger.Parse(txtX.Text.Trim());

                // Yêu cầu 1 của thầy: Kiểm tra xem P thủ công nhập vào có phải số nguyên tố không
                if (!MathHelper.IsPrime(p, 8))
                {
                    MessageBox.Show("LỖI: Giá trị P bạn nhập KHÔNG PHẢI là số nguyên tố! Vui lòng nhập số khác.", "Lỗi Xác Thực Khóa", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (x <= 1 || x >= p - 1)
                {
                    MessageBox.Show("LỖI: Khóa bí mật X phải thỏa mãn điều kiện (1 < x < p-1)!", "Lỗi Xác Thực Khóa", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                // Tự động tính toán lại Y dựa trên khóa thủ công hợp lệ vừa nhập
                BigInteger y = BigInteger.ModPow(g, x, p);
                txtY.Text = y.ToString();

                currentPublicKey = new ElGamalPublicKey { P = p, G = g, Y = y };
                currentPrivateKey = new ElGamalPrivateKey { X = x };

                MessageBox.Show("Cấu hình khóa thủ công HỢP LỆ! Hệ thống đã ghi nhận tham số.", "Thành công", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Dữ liệu khóa nhập vào không phải số nguyên hợp lệ! Chi tiết: {ex.Message}", "Lỗi Định Dạng", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnSaveKeys_Click(object sender, RoutedEventArgs e)
        {
            if (currentPublicKey == null)
            {
                MessageBox.Show("Không có dữ liệu khóa hợp lệ để lưu!");
                return;
            }

            SaveFileDialog saveDialog = new SaveFileDialog { Filter = "Text File (*.txt)|*.txt", Title = "Lưu file cấu hình khóa" };
            if (saveDialog.ShowDialog() == true)
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("=== ELGAMAL KEY CONFIG ===");
                sb.AppendLine($"P:{txtP.Text.Trim()}");
                sb.AppendLine($"G:{txtG.Text.Trim()}");
                sb.AppendLine($"Y:{txtY.Text.Trim()}");
                File.WriteAllText(saveDialog.FileName, sb.ToString());
                MessageBox.Show("Đã xuất file khóa thành công!");
            }
        }

        // ================= TAB 2: LOGIC KÝ VĂN BẢN =================
        private void BtnSelectFileToSign_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog { Filter = "Text Files (*.txt)|*.txt" };
            if (openDialog.ShowDialog() == true)
            {
                txtFilePathToSign.Text = openDialog.FileName;
                // Yêu cầu 2 của thầy: Đọc và hiển thị nội dung trực quan lên màn hình
                string content = File.ReadAllText(openDialog.FileName);
                txtContentToSign.Text = content;
            }
        }

        private void BtnPerformSign_Click(object sender, RoutedEventArgs e)
        {
            string content = txtContentToSign.Text;
            if (string.IsNullOrEmpty(content))
            {
                MessageBox.Show("Vui lòng nhập chữ hoặc tải file để lấy nội dung ký!");
                return;
            }
            if (currentPrivateKey == null)
            {
                MessageBox.Show("Hệ thống chưa có khóa bí mật! Hãy tạo hoặc check khóa ở Tab 1 trước.");
                return;
            }

            byte[] textBytes = Encoding.UTF8.GetBytes(content);
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hash = sha256.ComputeHash(textBytes);
                originalCapturedHash = BitConverter.ToString(hash).Replace("-", "");
                lblFileHash.Text = originalCapturedHash;

                var sig = ElGamalAlgorithm.Sign(hash, currentPublicKey, currentPrivateKey);
                txtSignatureResult.Text = $"{sig.r}|{sig.s}";
                MessageBox.Show("Đã tạo chữ ký số thành công!", "Thông báo", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void BtnSaveSignature_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtSignatureResult.Text))
            {
                MessageBox.Show("Chưa có chữ ký để xuất file!");
                return;
            }

            SaveFileDialog saveDialog = new SaveFileDialog { Filter = "Signature File (*.sig)|*.sig", Title = "Lưu file chứng thực chữ ký" };
            if (saveDialog.ShowDialog() == true)
            {
                // Yêu cầu 2: Lưu file chữ ký rời kèm thông tin băm đối chứng
                StringBuilder sb = new StringBuilder();
                sb.AppendLine($"ORIGINAL_HASH:{originalCapturedHash}");
                sb.AppendLine($"SIGNATURE:{txtSignatureResult.Text}");
                File.WriteAllText(saveDialog.FileName, sb.ToString());
                MessageBox.Show("Đã lưu file chữ ký (.sig) thành công!");
            }
        }

        // ================= TAB 3: LOGIC XÁC THỰC (BẮT 4 TRƯỜNG HỢP) =================
        private void BtnSelectFileToVerify_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog { Filter = "Text Files (*.txt)|*.txt" };
            if (openDialog.ShowDialog() == true)
            {
                txtFilePathToVerify.Text = openDialog.FileName;
                txtContentToVerify.Text = File.ReadAllText(openDialog.FileName);
            }
        }

        private void BtnLoadPublicKey_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog { Filter = "Text File (*.txt)|*.txt" };
            if (openDialog.ShowDialog() == true)
            {
                try
                {
                    string[] lines = File.ReadAllLines(openDialog.FileName);
                    currentPublicKey = new ElGamalPublicKey();
                    foreach (var line in lines)
                    {
                        if (line.StartsWith("P:")) currentPublicKey.P = BigInteger.Parse(line.Substring(2));
                        if (line.StartsWith("G:")) currentPublicKey.G = BigInteger.Parse(line.Substring(2));
                        if (line.StartsWith("Y:")) currentPublicKey.Y = BigInteger.Parse(line.Substring(2));
                    }
                    MessageBox.Show("Đã nạp khóa công khai đối sánh!");
                }
                catch { MessageBox.Show("Cấu trúc file khóa không đọc được!"); }
            }
        }

        private void BtnLoadSignatureFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog { Filter = "Signature File (*.sig)|*.sig" };
            if (openDialog.ShowDialog() == true)
            {
                try
                {
                    string[] lines = File.ReadAllLines(openDialog.FileName);
                    foreach (var line in lines)
                    {
                        if (line.StartsWith("SIGNATURE:"))
                        {
                            txtInputSignature.Text = line.Substring(10);
                        }
                        if (line.StartsWith("ORIGINAL_HASH:"))
                        {
                            originalCapturedHash = line.Substring(14);
                        }
                    }
                    MessageBox.Show("Đã nạp file chữ ký và mã băm đối chứng thành công!");
                }
                catch { MessageBox.Show("File chữ ký bị lỗi cấu trúc!"); }
            }
        }

        private void BtnPerformVerify_Click(object sender, RoutedEventArgs e)
        {
            string currentContent = txtContentToVerify.Text;
            if (string.IsNullOrEmpty(currentContent) || currentPublicKey == null || string.IsNullOrEmpty(txtInputSignature.Text))
            {
                MessageBox.Show("Vui lòng chuẩn bị đầy đủ: Văn bản, Khóa công khai và Chữ ký để xác thực!", "Thiếu dữ liệu", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                string[] sigParts = txtInputSignature.Text.Trim().Split('|');
                if (sigParts.Length != 2)
                {
                    MessageBox.Show("Chuỗi chữ ký sai cấu trúc dạng r|s!", "Lỗi định dạng", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                BigInteger r = BigInteger.Parse(sigParts[0].Trim());
                BigInteger s = BigInteger.Parse(sigParts[1].Trim());

                // 1. Tính toán mã băm của văn bản HIỆN TẠI trên ô nhập liệu
                byte[] currentHashBytes;
                string currentHash = string.Empty;
                using (SHA256 sha256 = SHA256.Create())
                {
                    byte[] currentBytes = Encoding.UTF8.GetBytes(currentContent);
                    currentHashBytes = sha256.ComputeHash(currentBytes);
                    currentHash = BitConverter.ToString(currentHashBytes).Replace("-", "").Trim();
                }

                // 2. KHẮC PHỤC LỖI: Chuyển đổi mã băm GỐC từ chuỗi Hex sang mảng Byte một cách chuẩn xác
                byte[] originalHashBytes = null;
                if (!string.IsNullOrEmpty(originalCapturedHash))
                {
                    // Sử dụng FromHexString để loại bỏ hoàn toàn lỗi convert thủ công
                    originalHashBytes = Convert.FromHexString(originalCapturedHash.Trim());
                }
                else
                {
                    // Nếu không nạp file .sig mà gõ tay, tạm thời lấy luôn mã băm hiện tại để test toán học
                    originalHashBytes = currentHashBytes;
                }

                // 3. Tiến hành kiểm tra 2 điều kiện độc lập
                bool isTextIntact = (currentHash.Equals(originalCapturedHash, StringComparison.OrdinalIgnoreCase));

                // Xác thực toán học ElGamal trên văn bản HIỆN TẠI (Dùng cho TH4 và TH2)
                bool verifyWithCurrentText = ElGamalAlgorithm.Verify(currentHashBytes, r, s, currentPublicKey);

                // Xác thực toán học ElGamal trên văn bản GỐC (Dùng cho TH1)
                bool verifyWithOriginalText = ElGamalAlgorithm.Verify(originalHashBytes, r, s, currentPublicKey);

                // --- PHÂN TÁCH CHÍNH XÁC 4 TRƯỜNG HỢP THEO ĐÚNG LOGIC ---

                // TH 4: Đúng cả 2 (Văn bản nguyên vẹn, chữ ký khớp hoàn hảo)
                if (isTextIntact && verifyWithCurrentText)
                {
                    brdResult.Background = new SolidColorBrush(Color.FromRgb(22, 163, 74)); // Xanh lá
                    txtVerifyStatus.Text = "TH4: XÁC THỰC CHÍNH XÁC - VĂN BẢN NGUYÊN VẸN, CHỮ KÝ HỢP LỆ.";
                }
                // TH 1: Chỉ lỗi văn bản (Văn bản bị sửa, nhưng toán học chứng minh chữ ký này ĐÚNG với bản gốc)
                else if (!isTextIntact && verifyWithOriginalText)
                {
                    brdResult.Background = new SolidColorBrush(Color.FromRgb(225, 29, 72)); // Đỏ hồng
                    txtVerifyStatus.Text = "TH1 LỖI: VĂN BẢN ĐÃ BỊ THAY ĐỔI HOẶC GIẢ MẠO!";
                }
                // TH 2: Chỉ lỗi chữ ký (Văn bản giữ nguyên chuẩn xác, nhưng chuỗi chữ ký gõ vào bị sai)
                else if (isTextIntact && !verifyWithCurrentText)
                {
                    brdResult.Background = new SolidColorBrush(Color.FromRgb(234, 88, 12)); // Cam
                    txtVerifyStatus.Text = "TH2 LỖI: CHỮ KÝ HOẶC KHÓA CÔNG KHAI KHÔNG HỢP LỆ!";
                }
                // TH 3: Lỗi cả hai (Văn bản bị sửa và chữ ký nạp vào cũng là chữ ký sai hoàn toàn)
                else
                {
                    brdResult.Background = new SolidColorBrush(Color.FromRgb(15, 23, 42)); // Đen xám
                    txtVerifyStatus.Text = "TH3 NGUY HIỂM: CẢ VĂN BẢN VÀ CHỮ KÝ ĐỀU SAI HOẶC BỊ SỬA ĐỔI!";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi xử lý dữ liệu: {ex.Message}", "Lỗi hệ thống", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}