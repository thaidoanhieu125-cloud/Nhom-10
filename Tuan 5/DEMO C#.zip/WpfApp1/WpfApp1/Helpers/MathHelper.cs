﻿using System;
using System.Numerics;
using System.Security.Cryptography;

namespace WpfApp1.Helpers
{
    public static class MathHelper
    {
        // 1. Thuật toán Euclid mở rộng để tìm nghịch đảo mô-đun: Tính (a^-1) mod m
        public static BigInteger ModInverse(BigInteger a, BigInteger m)
        {
            BigInteger m0 = m;
            BigInteger y = 0, x = 1;

            if (m == 1) return 0;

            while (a > 1)
            {
                if (m == 0) return 0; // Tránh lỗi chia cho 0 nếu tham số lỗi
                BigInteger q = a / m;
                BigInteger t = m;

                m = a % m;
                a = t;
                t = y;

                y = x - q * y;
                x = t;
            }

            if (x < 0) x += m0;
            return x;
        }

        // 2. Sinh số ngẫu nhiên lớn trong khoảng [lowerBound, upperBound]
        public static BigInteger RandomBigInteger(BigInteger lowerBound, BigInteger upperBound)
        {
            if (lowerBound >= upperBound)
                throw new ArgumentException("Lower bound must be less than upper bound.");

            using (RandomNumberGenerator rng = RandomNumberGenerator.Create())
            {
                BigInteger bytesRange = upperBound - lowerBound;
                byte[] bytes = bytesRange.ToByteArray();

                BigInteger value;
                do
                {
                    rng.GetBytes(bytes);
                    bytes[bytes.Length - 1] &= 0x7F; // Đảm bảo số luôn dương
                    value = new BigInteger(bytes);
                } while (value >= bytesRange);

                return lowerBound + value;
            }
        }

        // 3. Kiểm tra số nguyên tố bằng thuật toán Miller-Rabin (Độ chính xác cao cho số lớn)
        public static bool IsPrime(BigInteger n, int k = 10)
        {
            if (n <= 1 || n == 4) return false;
            if (n <= 3) return true;
            if (n % 2 == 0) return false;

            BigInteger d = n - 1;
            int s = 0;
            while (d % 2 == 0)
            {
                d /= 2;
                s++;
            }

            for (int i = 0; i < k; i++)
            {
                BigInteger a = RandomBigInteger(2, n - 2);
                BigInteger x = BigInteger.ModPow(a, d, n);

                if (x == 1 || x == n - 1)
                    continue;

                bool composite = true;
                for (int r = 1; r < s; r++)
                {
                    x = BigInteger.ModPow(x, 2, n);
                    if (x == n - 1)
                    {
                        composite = false;
                        break;
                    }
                }

                if (composite) return false; // Chắc chắn là hợp số
            }
            return true; // Có xác suất cao là số nguyên tố
        }

        // 4. Hàm sinh số nguyên tố ngẫu nhiên với độ dài bit chỉ định
        public static BigInteger GeneratePrime(int bitLength)
        {
            using (RandomNumberGenerator rng = RandomNumberGenerator.Create())
            {
                byte[] bytes = new byte[bitLength / 8];
                BigInteger p;
                do
                {
                    rng.GetBytes(bytes);
                    bytes[bytes.Length - 1] &= 0x7F; // Đảm bảo số dương
                    bytes[0] |= 0x01; // Đảm bảo là số lẻ
                    p = new BigInteger(bytes);
                } while (!IsPrime(p, 8)); // Lặp đến khi tìm được số nguyên tố
                return p;
            }
        }
    }
}