﻿using System;
using System.Numerics;
using WpfApp1.Helpers;

namespace WpfApp1.Core
{
    public class ElGamalAlgorithm
    {
        // 1. Sinh cặp khóa ngẫu nhiên
        public static (ElGamalPublicKey pubKey, ElGamalPrivateKey privKey) GenerateKeys(int bitLength)
        {
            // Sinh số nguyên tố p
            BigInteger p = MathHelper.GeneratePrime(bitLength);

            // Chọn g là một phần tử nguyên thủy (ở demo này chọn số nhỏ hợp lệ để tối ưu tốc độ)
            BigInteger g = 2;
            while (BigInteger.ModPow(g, (p - 1) / 2, p) == 1)
            {
                g++;
            }

            // Sinh khóa bí mật x sao cho 1 < x < p-1
            BigInteger x = MathHelper.RandomBigInteger(2, p - 1);

            // Tính khóa công khai y = g^x mod p
            BigInteger y = BigInteger.ModPow(g, x, p);

            return (new ElGamalPublicKey { P = p, G = g, Y = y }, new ElGamalPrivateKey { X = x });
        }

        // 2. Ký số dựa trên giá trị băm của file
        public static (BigInteger r, BigInteger s) Sign(byte[] hashBytes, ElGamalPublicKey pubKey, ElGamalPrivateKey privKey)
        {
            // Chuyển mảng byte hash thành một số BigInteger dương
            BigInteger m = new BigInteger(hashBytes, isUnsigned: true, isBigEndian: true);
            BigInteger p = pubKey.P;
            BigInteger g = pubKey.G;
            BigInteger x = privKey.X;
            BigInteger pMinus1 = p - 1;

            BigInteger k, r, s;

            // Sinh số ngẫu nhiên k sao cho gcd(k, p-1) = 1
            do
            {
                k = MathHelper.RandomBigInteger(2, pMinus1);
            } while (BigInteger.GreatestCommonDivisor(k, pMinus1) != 1);

            // Tính r = g^k mod p
            r = BigInteger.ModPow(g, k, p);

            // Tính s = k^-1 * (m - x*r) mod (p-1)
            BigInteger kInverse = MathHelper.ModInverse(k, pMinus1);
            BigInteger transmission = (m - (x * r)) % pMinus1;

            if (transmission < 0)
                transmission += pMinus1; // Đảm bảo số dư luôn dương trong C#

            s = (kInverse * transmission) % pMinus1;

            return (r, s);
        }

        // 3. Xác thực chữ ký số
        public static bool Verify(byte[] hashBytes, BigInteger r, BigInteger s, ElGamalPublicKey pubKey)
        {
            BigInteger m = new BigInteger(hashBytes, isUnsigned: true, isBigEndian: true);
            BigInteger p = pubKey.P;
            BigInteger g = pubKey.G;
            BigInteger y = pubKey.Y;

            // Điều kiện biên kiểm tra tính hợp lệ của chữ ký
            if (r <= 0 || r >= p || s <= 0 || s >= p - 1)
                return false;

            // Vế trái V1 = g^m mod p
            BigInteger v1 = BigInteger.ModPow(g, m, p);

            // Vế phải V2 = (y^r * r^s) mod p
            BigInteger temp1 = BigInteger.ModPow(y, r, p);
            BigInteger temp2 = BigInteger.ModPow(r, s, p);
            BigInteger v2 = (temp1 * temp2) % p;

            return v1 == v2;
        }
    }
}