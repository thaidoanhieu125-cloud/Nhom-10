﻿using System.Numerics;

namespace WpfApp1.Core
{
    public class ElGamalPublicKey
    {
        public BigInteger P { get; set; }
        public BigInteger G { get; set; }
        public BigInteger Y { get; set; }
    }

    public class ElGamalPrivateKey
    {
        public BigInteger X { get; set; }
    }
}